# Environment setting
from __future__ import print_function
import os
import copy
import time
import random
import numpy as np
import pandas as pd
import seaborn as sns
import scipy.special as sps
import matplotlib.pyplot as plt
from matplotlib import cm
from tensorboard.notebook import display

plt.style.use('dark_background')
color_list = ['#8DD3C7', '#FEFFB3', '#BFBBD9', '#FA8174', '#81B1D2', '#FDB462', '#B3DE69', '#BC82BD', '#CCEBC4']

# Get data
import os
file_paths = []
for dirname, _, filenames in os.walk('Singh'):
    for filename in filenames:
        file_paths.append(os.path.join(dirname, filename))
        print(os.path.join(dirname, filename))

# Get data / Check table
age_raw = pd.read_csv('Singh/TimeAge.csv')
age_raw.tail(9)

# Unique age groups : 9
age_list = age_raw.age.unique()
# 80s == 80s and older
age_list

# Date range : 2020-03-02 to 2020-03-30 (29 days)
age_raw.head(3).append(age_raw.tail(3))

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Accumulated Confirmed Cases by Age (as of 2020-03-30)', fontsize=15)
plt.bar(age_list, age_raw.confirmed[-9:])
plt.show()

# Get population distribution table
pop_order = pd.DataFrame()
pop_order['age'] = age_list
pop_order['population'] = (4055740, 4732100, 6971785, 7203550, 8291728, 8587047, 6472987, 3591533, 1874109)
pop_order['proportion'] = round(pop_order['population']/sum(pop_order['population']) * 100, 2)
pop_order = pop_order.sort_values('population', ascending=False)
pop_order.set_index(np.arange(1, 10), inplace=True)
pop_order

# Distribution Graph
fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Population Distribution (2020)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(pop_order.proportion, labels=pop_order.age, autopct='%.2f%%');
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

# get a new table with population / proportion by age
confirmed_by_population = pop_order.sort_values('age')
confirmed_by_population['confirmed'] = list(age_raw[-9:].confirmed)
# get confirmed ratio regarding population
confirmed_by_population['confirmed_ratio'] = confirmed_by_population['confirmed']/confirmed_by_population['population'] * 100;
confirmed_by_population

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Population-based Confirmed Ratio by Age', fontsize=15)
plt.bar(age_list, confirmed_by_population.confirmed_ratio[-9:]);

# Compare two graphs
fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(23, 7))

axes[0].set_title('Confirmed Cases by Age', fontsize=15)
axes[0].bar(age_list, age_raw.confirmed[-9:])

axes[1].set_title('Population-based Confirmed Ratio', fontsize=15)
axes[1].bar(age_list, confirmed_by_population.confirmed_ratio[-9:])

plt.show()

# Save raw data before manipulating the copy
age = copy.deepcopy(age_raw)
age.tail(3)

# delete unnecessary column(s)
print(age.time.describe())
del age['time']
age.tail(3)

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Confirmed cases by age (accumulated)', fontsize=15)
plt.xticks(rotation=31)
confirmed_set = age.confirmed.groupby(age.age)
for confirmed_each, age_each in zip(confirmed_set, age_list):
    plt.plot(age.date.unique(), confirmed_each[1], label=age_each)
ax.legend()
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Deceased cases by age (accumulated)', fontsize=15)
plt.xticks(rotation=31)
deceased_set = age.deceased.groupby(age.age)
for deceased_each, age_each in zip(deceased_set, age_list):
    plt.plot(age.date.unique(), deceased_each[1], label=age_each)
ax.legend()
plt.show()

age_deceased = age.tail(9)[['age', 'deceased']]
age_deceased.set_index(np.arange(0, len(age.age.unique())), inplace=True)
age_deceased.T

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Deceased rate by age (accumulated)', fontsize=15)
plt.xticks(rotation=31)
ratio_set = (age.deceased/age.confirmed * 100.0).groupby(age.age)
for ratio_each, age_each in zip(ratio_set, age_list):
    plt.plot(age.date.unique(), ratio_each[1], label=age_each)
ax.legend()
plt.show()

fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(23, 7))

axes[0].set_title('Confirmed cases by age (accumulated)', fontsize=15)
confirmed_set = age.confirmed.groupby(age.age)
for confirmed_each, age_each in zip(confirmed_set, age_list):
    axes[0].plot(np.arange(1,len(age.date.unique())+1), confirmed_each[1], label=age_each)
axes[0].legend()
axes[1].set_title('Deceased cases by age (accumulated)', fontsize=15)
deceased_set = age.deceased.groupby(age.age)
for deceased_each, age_each in zip(deceased_set, age_list):
    axes[1].plot(np.arange(1,len(age.date.unique())+1), deceased_each[1], label=age_each)
axes[1].legend()

fig, ax = plt.subplots(figsize=(10.5, 7))
plt.title('Deceased ratio by age (accumulated)', fontsize=15)
ratio_set = (age.deceased/age.confirmed * 100.0).groupby(age.age)
for ratio_each, age_each in zip(ratio_set, age_list):
    plt.plot(np.arange(1,len(age.date.unique())+1), ratio_each[1], label=age_each)
ax.legend()

plt.show()

# 3 plots in a row
fig, axes = plt.subplots(nrows=3, ncols=1, figsize=(23, 23))

axes[0].set_title('Confirmed cases by age (accumulated)', fontsize=17)
axes[0].tick_params(labelrotation=31)
confirmed_set = age.confirmed.groupby(age.age)
for confirmed_each, age_each in zip(confirmed_set, age_list):
    axes[0].plot(age.date.unique(), confirmed_each[1], label=age_each)
axes[0].legend()

axes[1].set_title('Deceased cases by age (accumulated)', fontsize=17)
axes[1].tick_params(labelrotation=31)
deceased_set = age.deceased.groupby(age.age)
for deceased_each, age_each in zip(deceased_set, age_list):
    axes[1].plot(age.date.unique(), deceased_each[1], label=age_each)
axes[1].legend()

axes[2].set_title('Deceased ratio by age (accumulated)', fontsize=17)
axes[2].tick_params(labelrotation=31)
ratio_set = (age.deceased/age.confirmed * 100.0).groupby(age.age)
for ratio_each, age_each in zip(ratio_set, age_list):
    axes[2].plot(age.date.unique(), ratio_each[1], label=age_each)
axes[2].legend()

plt.show()

# 1071 rows in total: cases in each province on a certain date
location_raw = pd.read_csv('Singh/TimeProvince.csv')
location_raw.tail(3).T

# For 71 days (from 2020-01-20 to 2020-03-30)
print(len(location_raw.date.unique()))
print(min(location_raw.date), max(location_raw.date))

# confirmed: 159.43 / released: 16.60 / deceased: 1.33 (mean)
location_raw.describe()

# There are 17 provinces (we call it location from now on)
print(len(location_raw.province.unique()))

# each location has 71 rows
print(17*71) # number of rows matches
location_raw[location_raw.province=='Jeju-do']

# Two locations (Daegu | Gyeongsangbuk-do) have overwhelming numbers of cases
confirmed_cases = location_raw.groupby(location_raw.province).describe()['confirmed']
confirmed_cases = confirmed_cases.sort_values('max', ascending=False)
pd.DataFrame(confirmed_cases['max'])
# as of 2020-03-30

# Total
total_list = []
for i in location_raw.confirmed.groupby(location_raw.date):
    total_list.append(sum(i[1]))
fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Accumulated Confirmed Cases (TOTAL)', fontsize=15)
plt.plot(np.arange(1, len(total_list)+1), total_list) # from day1(2020-01-20) to day71(2020-03-30)
plt.show()

total_df = pd.DataFrame(total_list, index=location_raw.date.unique())
total_df.columns = ['confirmed']

total_df[total_df.confirmed < 150].tail(3).T

total_df[total_df.confirmed > 7900].head(3).T

# location list by order of confirmed cases (based on latest data)
loc_list = location_raw[location_raw.date==location_raw.date.iloc[-1]]\
           .sort_values('confirmed', ascending = False)\
           .province
# Get a graph for each location
for loc_name in loc_list:
    fig, ax = plt.subplots(figsize=(13, 7))
    plt.title('Confirmed Cases ({0})'.format(loc_name.upper()), fontsize=15)
    loc_raw = location_raw[location_raw.province==loc_name]
    plt.plot(np.arange(1, len(total_list)+1), loc_raw.confirmed)
    plt.show()
# click output to check all graphs

# Get the latest distribution of accumulated confirmed case
print(len(location_raw[location_raw.date==location_raw.date.iloc[-1]])) # number of locations matches

loc_latest = location_raw[location_raw.date==location_raw.date.iloc[-1]]
del loc_latest['date']
del loc_latest['time']
loc_latest = loc_latest.iloc[:, :2]
loc_latest['proportion'] = round(loc_latest.confirmed / sum(loc_latest.confirmed) * 100, 2)
loc_latest = loc_latest.sort_values('proportion', ascending=False)
loc_latest.set_index(np.arange(1, len(loc_latest)+1), inplace=True)
loc_latest_all = copy.deepcopy(loc_latest)
loc_latest_all

# Put locations with less than or equal to 1% into "Others"
loc_latest.loc['18',:] = loc_latest.iloc[6:, :].sum()
loc_latest.loc['18','province'] = 'Others'
loc_latest = loc_latest[loc_latest.proportion > 1]
loc_latest

# Distribution Graph
fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Confrimed Case Location Distribution (2020-03-30)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(loc_latest.proportion, labels=loc_latest.province, autopct='%.2f%%', explode=(0.03,0,0,0,0,0,0))
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()


loc_excl_special = location_raw[location_raw.province != 'Daegu'][location_raw.province != 'Gyeongsangbuk-do']
confirmed_excl_special = dict()
for i in loc_excl_special.groupby('date'):
    confirmed_excl_special[i[0]] = sum(i[1].confirmed)
len(confirmed_excl_special)
# size matches

'''
fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Confirmed Cases (excluding Daegu, Gyeongsangbuk-do)')
plt.plot(np.arange(1, len(total_list)+1), confirmed_excl_special.values())
plt.show()


fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(23, 7))

axes[0].set_title('Confirmed cases by time (excluding 2 special cases)', fontsize=15)
axes[0].plot(np.arange(1, len(total_list)+1), confirmed_excl_special.values())

axes[1].set_title('Confirmed cases by time (total)', fontsize=15)
axes[1].plot(np.arange(1, len(total_list)+1), total_list, color=color_list[1])

axes[2].set_title('Confirmed cases by time (overlapped)', fontsize=15)
axes[2].plot(np.arange(1, len(total_list)+1), confirmed_excl_special.values())
axes[2].plot(np.arange(1, len(total_list)+1), total_list)

plt.show()

'''

loc_meta_raw = pd.read_csv('Singh/Region.csv')
loc_meta_raw.tail(3).T

len(loc_meta_raw.province.unique()), loc_meta_raw.province.unique()

loc_meta_raw[loc_meta_raw.province == 'Korea'].T

avg_old_pop = dict()
for i in loc_meta_raw.iloc[:-2,:]['elderly_population_ratio'].groupby(loc_meta_raw.province):
    avg_old_pop[i[0]] = np.average(i[1])

old_pop_df = pd.DataFrame()

old_pop_df['location'] = avg_old_pop.keys()
old_pop_df['old_population_proportion'] = avg_old_pop.values()
old_pop_df = old_pop_df.sort_values('old_population_proportion', ascending=False)
old_pop_df

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Old population proportion by location', fontsize=17)
plt.xticks(rotation=23)
plt.bar(old_pop_df.location, old_pop_df.old_population_proportion, color=color_list[1])
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Confirmed cases proportion by location', fontsize=17)
plt.xticks(rotation=43)
plt.bar(loc_latest_all.province, loc_latest_all.proportion, color=color_list[1])
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Confirmed cases proportion by location (Excluding 2 special cases)', fontsize=17)
plt.xticks(rotation=43)
plt.bar(loc_latest_all[2:].province, loc_latest_all[2:].proportion, color=color_list[1])
plt.show()

pop_dense = pd.DataFrame()
pop_dense['location'] = loc_latest_all.province
pop_dense['population'] = [2450, 2674, 13031, 9705, 2180, 3400
                           , 3356, 304, 2939, 1154, 1619, 1521
                           , 1518, 1493, 1820, 1790, 653]
pop_dense['population'] *= 1000
# density = number of people / km²
pop_dense['density'] = [2773, 141, 1279, 16034, 265, 4416
                        , 318, 653, 2764, 1088, 219, 90
                        , 2813, 2980, 226, 145, 353]
pop_dense

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Population (order by Confirmed cases)', fontsize=15)
plt.xticks(rotation=43)
plt.bar(pop_dense.location, pop_dense.population, color=color_list[1])
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Population Density (order by Confirmed cases)', fontsize=15)
plt.xticks(rotation=43)
plt.bar(pop_dense.location, pop_dense.density, color=color_list[1])
plt.show()

gender_raw = pd.read_csv('Singh/TimeGender.csv')
gender_raw.head(3).append(gender_raw.tail(3))

fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Confirmed Cases (2020-03-30)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(gender_raw.confirmed[-2:], labels=['male', 'female'], autopct='%.2f%%') # 3430 VS. 5467
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Confirmed cases by gender (accumulated)', fontsize=15)
plt.xticks(rotation=31)
genders_confirmed = (gender_raw[gender_raw.sex=='male'].confirmed, gender_raw[gender_raw.sex=='female'].confirmed)
for gender_each, gender_label in zip(genders_confirmed, ['male', 'female']):
    plt.plot(gender_raw.date.unique(), gender_each, label=gender_label)
ax.legend()
plt.show()

fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Deceased Cases (2020-03-30)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(gender_raw.deceased[-2:], labels=['male', 'female'], autopct='%.2f%%') # 55 VS. 49
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Deceased cases by gender (accumulated)', fontsize=15)
plt.xticks(rotation=31)
genders_deceased = (gender_raw[gender_raw.sex=='male'].deceased, gender_raw[gender_raw.sex=='female'].deceased)

for gender_each, gender_label in zip(genders_deceased, ['male', 'female']):
    plt.plot(gender_raw.date.unique(), gender_each, label=gender_label)
ax.legend()
plt.show()

fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Gender Balance (2020-02)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie([25860491, 25984136], labels=['male', 'female'], autopct='%.2f%%') # male:female = 100:99.5 (almost same)
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

pop_meta = copy.deepcopy(pop_dense)
pop_meta['gender_bal'] = [97.7, 101.4, 101.2, 95.1, 104.0, 96.3, 101.3, 99.4, 100.5
                          , 105.7, 102.7, 101.2, 99.8, 98.0, 98.9, 100.9, 101.1]
pop_meta

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Gender Balance - Location (order by Confirmed cases)', fontsize=15)
plt.xticks(rotation=43)
plt.bar(pop_meta.location, pop_meta.gender_bal, color=color_list[3])
plt.show()

# From 2020-01-20 to 2020-03-30 for 71 days
test_raw = pd.read_csv('Singh/Time.csv')
test_raw.head(3).append(test_raw.tail(3))

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Tests And Results (All)', fontsize=15)
for test_each in test_raw.columns[2:]:
    plt.plot(np.arange(1, len(total_list)+1), test_raw[test_each], label=test_each) # first to last day on the data
ax.legend()
plt.show()

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Tests And Results (confirmed | released | deceased)', fontsize=15)
for test_each in test_raw.columns[4:]:
    plt.plot(np.arange(1, len(total_list)+1), test_raw[test_each], label=test_each)
ax.legend()
plt.show()


fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Tests And Results (deceased)', fontsize=15)
plt.plot(np.arange(1, len(total_list)+1), test_raw['deceased'], label='deceased')
ax.legend()
plt.show()

test_raw['confirmed_rate'] = test_raw.confirmed/test_raw.test * 100
# to total tests
test_raw['deceased_rate'] = test_raw.deceased/test_raw.confirmed * 100
# to total confirmed cases (0.0313% to total tests)
test_raw.tail(1)

total_pop = sum(pop_meta.population*1000)
test_ratio = 395194/sum(pop_meta.population*1000) * 100
total_pop, test_ratio

# check raw data
cause_raw = pd.read_csv('Singh/Case.csv')
cause_raw.head(3).append(cause_raw.tail(3))

# order by confirmed cases (most to least)
cause = cause_raw.sort_values('confirmed', ascending=False)
cause.head(3).append(cause.tail(3))

print('No. of causes: {}'.format(len(cause.infection_case.unique())))
print(cause.infection_case.unique()[:3])

# Put cuases other than those with 5 most confirmed cases into others
cause.loc[len(cause), :] = cause[cause.confirmed<cause.confirmed.iloc[4]].sum()
cause.loc[len(cause)-1, 'case_id'] = 0
cause.loc[len(cause)-1, 'province'] = 'Mixed'
cause.loc[len(cause)-1, 'city'] = 'Mixed'
cause.loc[len(cause)-1, 'group'] = 'Mixed'
cause.loc[len(cause)-1, 'infection_case'] = 'Others'
cause.loc[len(cause)-1, 'latitude'] = '-'
cause.loc[len(cause)-1, 'longitude'] = '-'
cause_with_others = cause[cause.confirmed >= cause.confirmed.iloc[4]]
cause_with_others

# Distribution Graph
fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Cause of Infection (2020-03-20)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(cause_with_others.confirmed, autopct='%.2f%%'
        , labels=cause_with_others.infection_case + ' (' + cause_with_others.province + ')'
        , explode=(0.03, 0, 0, 0, 0, 0))
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

cause_group = cause_raw.groupby('group').sum().sort_values('confirmed', ascending=False)
cause_group.index = ['group', 'individual']
cause_group

fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Type of infection (2020-03-20)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(cause_group.confirmed, autopct='%.2f%%'
        , labels=cause_group.index)
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

weather_raw = pd.read_csv('Singh/Weather.csv')
weather_raw.head(3).append(weather_raw.tail(3))

weather_raw.loc[:,'avg_temp':].describe()

# Stats by group
print(len(weather_raw.province.unique()), len(location_raw.province.unique()))
print(weather_raw.province.unique())
print(location_raw.province.unique())

weather_stat = weather_raw.loc[:, 'province':].groupby('province').mean()
weather_stat

weather_avg = pd.DataFrame(
    [weather_stat.index
     , weather_stat['avg_temp']
     , weather_stat['precipitation']
     , weather_stat['max_wind_speed']
     , weather_stat['avg_relative_humidity']
    ]
).T
weather_avg.columns = ['location', 'temperature', 'precipitation'
                       , 'max_wind_speed', 'relative_humidity']
weather_avg.head(3)

sorter = list(pop_meta.location[pop_meta.location != 'Sejong'].values)

weather_avg.location = weather_avg.location.astype('category')
weather_avg.location.cat.set_categories(sorter, inplace=True)

weather_avg = weather_avg.sort_values(['location'])
weather_avg.head(3)

title_list = ['Average temperature', 'Average precipitation'
              , 'Maximun Wind Speed', 'Average relative humidity']

for col, title in zip(weather_avg.columns[1:], title_list):
    plt.figure(figsize=(13, 7))
    plt.title('{0} by location (from 2016-01-01)'.format(title), fontsize=15)
    plt.xticks(rotation=37)
    plt.bar(weather_avg.location, weather_avg[col], color=color_list[2])
    plt.show()

# create a dataframe
weather_covid = weather_raw[weather_raw.date >= '2019-11-17']
weather_cov_stat = weather_covid.loc[:, 'province':].groupby('province').mean()
weather_cov_avg = pd.DataFrame(
    [weather_cov_stat.index
     , weather_cov_stat['avg_temp']
     , weather_cov_stat['precipitation']
     , weather_cov_stat['max_wind_speed']
     , weather_cov_stat['avg_relative_humidity']
    ]
).T
# order by confirmed cases
weather_cov_avg.columns = ['location', 'temperature', 'precipitation', 'max_wind_speed', 'relative_humidity']
weather_cov_avg.location = weather_cov_avg.location.astype('category')
weather_cov_avg.location.cat.set_categories(sorter, inplace=True)
weather_cov_avg = weather_cov_avg.sort_values(['location'])
weather_cov_avg.head(3)

for col, title in zip(weather_cov_avg.columns[1:], title_list):
    plt.figure(figsize=(13, 7))
    plt.title('{0} by location (from 2019-11-17)'.format(title), fontsize=15)
    plt.xticks(rotation=37)
    plt.bar(weather_cov_avg.location, weather_cov_avg[col], color=color_list[2])
    plt.show()

patient_raw = pd.read_csv('Singh/PatientInfo.csv')
patient_raw.head(3).append(patient_raw.tail(3)).T

print('No. of confirmed cases (2020-03-30):', test_raw.iloc[-1, :].confirmed)

gender_dis = patient_raw[['patient_id', 'sex']].groupby('sex', as_index=False).count()
gender_dis.columns = ['gender', 'confirmed']
gender_dis
fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Gender Distribution of Confirmed Cases (in patient data)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(gender_dis.confirmed, labels=['female', 'male'], autopct='%.2f%%');
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

# get proportion in patient data
gender_dis['proportion'] = round(gender_dis.iloc[:, -1]/sum(gender_dis.confirmed) * 100, 2).values
# get proportion in gender data
gender_raw_dis = gender_raw.iloc[-2:, [2,3]]
gender_raw_dis['proportion'] = round(gender_raw_dis.iloc[:,-1]
                                     /sum(gender_raw_dis.confirmed) * 100, 2).values
# show difference

print(gender_dis.sort_values('confirmed', ascending=False))
print(gender_raw_dis.sort_values('confirmed', ascending=False))

print(len(patient_raw.infection_order.unique()))
print(patient_raw.infection_order.unique())

print(len(patient_raw), sum(patient_raw.infection_order.isna()))
print(len(patient_raw)- sum(patient_raw.infection_order.isna()))

order_stat = patient_raw[['patient_id', 'infection_order']].groupby('infection_order').count()
order_stat.columns = ['confirmed']
order_stat

patient_raw.contact_number.describe()

print(patient_raw.contact_number.value_counts())

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Number of contacts by a patient before confirmed', fontsize=15)
sns.swarmplot(patient_raw['contact_number'], color = color_list[5])
plt.show()

patient_outliers = patient_raw[patient_raw.contact_number >= 200].sort_values('contact_number', ascending=False)
patient_outliers[['contact_number', 'sex', 'age', 'country', 'province', 'disease',
                   'infection_case', 'confirmed_date', 'state']]

patient_inliers = patient_raw[ np.logical_not(patient_raw.patient_id.isin(patient_outliers.patient_id)) ]
patient_inliers.sort_values('contact_number', ascending=False).head(3)

patient_time_contact = patient_inliers[['contact_number', 'confirmed_date']].groupby('confirmed_date').mean()
patient_time_contact.head(3).append(patient_time_contact.tail(3))

fig, ax = plt.subplots(figsize=(13, 7))
plt.title('Average contacts by a patient (by confirmed date)', fontsize=15)
plt.bar(np.arange(1, len(patient_time_contact)+1)
        , patient_time_contact.contact_number
        , color = color_list[5])
plt.show()

route_raw = pd.read_csv('Singh/PatientRoute.csv')
route_raw.head(3).append(route_raw.tail(3))

print(len(route_raw.province.unique()))
print(route_raw.province.unique())

# make a dataframe
route_location = pd.DataFrame()
route_location['location'] = route_raw.groupby('province').count().index
route_location['logs'] = route_raw.groupby('province').count().patient_id.values
# put location with less than 10 logs into others
route_location.loc[len(route_location), 'location'] = 'others'
route_location.loc[len(route_location)-1, 'logs'] = route_location[route_location.logs <= 10 ].logs.sum()
route_location = route_location[ route_location.logs >= 10]
# order by logs
route_location = route_location.sort_values('logs', ascending=False)
route_location

# Distribution Graph
fig, ax = plt.subplots(figsize=(11, 11))
plt.title('Route Data Distribution by Location (2020-03-30)', fontsize=15)
pop_circle=plt.Circle((0,0), 0.73, color='black')
plt.pie(route_location.logs, labels=route_location.location, autopct='%.2f%%')
p=plt.gcf()
p.gca().add_artist(pop_circle)
plt.show()

# make a dataframe
route_patient = pd.DataFrame()
route_patient['patient'] = route_raw.groupby('patient_id').count().index
route_patient['logs'] = route_raw.groupby('patient_id').count().date.values
route_patient = route_patient.sort_values('logs', ascending=False)
route_patient.head(3).append(route_patient.tail(3))

# basic stats
route_patient.logs.describe()

# histogram
plt.figure(figsize = (13, 7))
plt.title('Route Data Histogram by patient (2020-03-30)', fontsize=15)
plt.hist(route_patient.logs.values, color = color_list[6])
plt.show()

route_patient.iloc[0, :]

patient_raw[ patient_raw.patient_id == route_patient.iloc[0, 0] ]

# make a dataframe
route_type = pd.DataFrame()
route_type['activity'] = route_raw.groupby('type').count().index
route_type['logs'] = route_raw.groupby('type').count().patient_id.values
route_type = route_type.sort_values('logs', ascending=False)
route_type.head(3).append(route_type.tail(3))

# graph
plt.figure(figsize = (13, 7))
plt.title('Route Data Frequency by Activity Type (2020-03-30)', fontsize=15)
plt.bar(route_type.activity[:7], route_type.logs[:7], color = color_list[6], width=0.5)
plt.xticks(rotation=13)
plt.show()


seoul_raw = pd.read_csv('Singh/SeoulFloating.csv')
seoul_raw.head(3).append(seoul_raw.tail(3))

plt.figure(figsize=(13,7))
plt.title('Floating Population by Date', size=17)

seoul_raw.groupby(['date', 'hour']).sum()\
         .groupby('date').mean().apply(lambda x: x/1000000)\
         .fp_num.plot(kind='bar', color=color_list[7])
plt.ylabel('floating population (million)', size=13)
plt.xticks(rotation=51, size=9)
plt.xlabel('date', size=13)
plt.show()

plt.figure(figsize=(13,7))
plt.title('Floating Population by Time', size=17)

# outlier
seoul_raw[ seoul_raw.date == '2020-02-23' ].groupby('hour')\
                                           .sum().apply(lambda x: x/1000000)\
                                           .fp_num.plot(color=color_list[7])
# normal
seoul_raw[ seoul_raw.date == '2020-02-29' ].groupby('hour')\
                                           .sum().apply(lambda x: x/1000000)\
                                           .fp_num.plot(color=color_list[0])

plt.ylabel('floating population (million)', size=13)
plt.xlabel('time', size=13)
plt.legend(['outlier', 'normal'], fontsize=11)
plt.show()

print(seoul_raw[seoul_raw.date=='2020-02-23'][seoul_raw.hour!=11].tail(1))
seoul_raw[seoul_raw.date=='2020-02-23'][seoul_raw.hour!=11].fp_num = seoul_raw[seoul_raw.date=='2020-02-23'][seoul_raw.hour!=11].fp_num/2
print(seoul_raw[seoul_raw.date=='2020-02-23'][seoul_raw.hour!=11].tail(1))

plt.figure(figsize=(13,7))
plt.title('Floating Population by Time', size=17)

# outlier
seoul_raw[ seoul_raw.date == '2020-02-23' ].groupby('hour')\
                                           .sum().apply(lambda x: x/1000000)\
                                           .fp_num.plot(color=color_list[7])
# normal
seoul_raw[ seoul_raw.date == '2020-02-29' ].groupby('hour')\
                                           .sum().apply(lambda x: x/1000000)\
                                           .fp_num.plot(color=color_list[0])

plt.ylabel('floating population (million)', size=13)
plt.xlabel('time', size=13)
plt.legend(['outlier', 'normal'], fontsize=11)
plt.show()



